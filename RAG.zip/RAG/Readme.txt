
# **Chat with PDFs and Websites Using RAG Pipeline**

This project implements a **Retrieval-Augmented Generation (RAG) pipeline** that enables users to interact with semi-structured data from **PDF files** and structured/unstructured content from **websites**. The system uses text extraction, chunking, embeddings, and a vector database for efficient retrieval and response generation.

---

## **Table of Contents**

1. Features
2. Tech Stack  
3. Setup Instructions
4. How to Run  
5. Example Queries  
6. API Endpoints  
7. Future Enhancements

---

## **Features**

1. **Chat with PDFs**:
   - Extracts and processes text, tables, and semi-structured data from PDF files.
   - Allows users to query specific details (e.g., unemployment rates, tabular data).
   - Handles comparison queries (e.g., comparing fields across multiple PDFs).

2. **Chat with Websites**:
   - Crawls and scrapes content from target websites.
   - Allows natural language queries for structured/unstructured web data.
   - Ensures accurate and context-rich responses using an LLM.

3. **RAG Pipeline**:
   - **Text Chunking**: Segments extracted content into manageable chunks.
   - **Embeddings**: Converts chunks and queries into embeddings for similarity search.
   - **Vector Search**: Retrieves the most relevant content using a vector database.
   - **Response Generation**: Generates accurate, fact-based answers using an LLM.

---

## **Tech Stack**

- **Backend**: Flask, FastAPI
- **LLM**: OpenAI GPT (or any preferred LLM)
- **Embeddings**: OpenAI Embeddings, Sentence Transformers
- **Vector Database**: Pinecone, ChromaDB, FAISS, or Weaviate
- **PDF Processing**: PyPDF2, PDFMiner, PyMuPDF
- **Web Scraping**: BeautifulSoup, Scrapy, Playwright
- **Orchestration**: LangChain, LlamaIndex
- **Utilities**: Pandas, NumPy, dotenv

---

## **Setup Instructions**

### **1. Prerequisites**

- **Python** (>=3.9)  
- API keys for:
   - OpenAI (for LLM and embeddings)
   - Vector Database (Pinecone, ChromaDB, or other)  

---

### **2. Clone the Repository**

```bash
git clone https://github.com/teja85053?tab=repositories/chat-with-pdfs-and-websites.git
cd chat-with-pdfs-and-websites
```

---

### **3. Install Dependencies**

Use the provided `requirements.txt` file to install all necessary libraries:

```bash
pip install -r requirements.txt
```

---

### **4. Configure Environment Variables**

Create a `.env` file in the project root directory and add your API keys and configuration:

```plaintext
OPENAI_API_KEY=tc8488UHqwINDCba8bo2bqu75EDDHYFHM9r3C5dVPMQ7IRKeyVJEsMAAFv3TnKPsIeVQ_QlBdJT3BlbkFJA7iO9pnzIJEzevXgyO4drN3PlpxKZW9z97mz5sSxaJ7FJKtw2eP2FQ_2ZeUxlZGVHtQJKg3Z0A
VECTOR_DB_API_KEY=your_vector_database_key
```

---

### **5. Prepare Data**

#### **PDF Data**:
1. Place PDF files in the `data/pdfs` directory.
2. Run the ingestion script to extract, chunk, and embed the PDF data:

```bash
python ingest_pdfs.py
```

#### **Website Data**:
1. Update the `websites.txt` file with target website URLs (one URL per line).
2. Run the web scraping ingestion script:

```bash
python ingest_websites.py
```

---

## **How to Run**

### **Start the Backend API**

Run the Flask or FastAPI server to expose the API endpoints:

```bash
python app.py
```

- The server will run on **http://127.0.0.1:8000**.

---

## **API Endpoints**

### **1. Query PDF Data**
- **Endpoint**: `/query-pdf`
- **Method**: POST
- **Payload**:
   ```json
   {
     "query": "What is the unemployment rate for Bachelor's degree holders?",
     "files": ["file1.pdf", "file2.pdf"]
   }
   ```
- **Response**:
   ```json
   {
     "response": "The unemployment rate for Bachelor's degree holders is 4.1%."
   }
   ```

### **2. Query Website Data**
- **Endpoint**: `/query-website`
- **Method**: POST
- **Payload**:
   ```json
   {
     "query": "What programs are offered at the University of Chicago?",
     "urls": ["https://www.uchicago.edu/"]
   }
   ```
- **Response**:
   ```json
   {
     "response": "The University of Chicago offers programs such as undergraduate studies, graduate studies, and professional programs."
   }
   ```

---

## **Example Queries**

1. **PDF Queries**:
   - "What is the unemployment rate for Master's degree holders on page 2?"
   - "Extract the tabular data from page 6."

2. **Website Queries**:
   - "What research programs are available at Stanford University?"
   - "List the undergraduate programs at the University of North Dakota."

3. **Comparison Queries**:
   - "Compare the unemployment rates for Bachelor's and Master's degrees across the given PDFs."
---

## **Future Enhancements**

- Add **real-time crawling** of websites on user request.
- Implement **advanced filtering** for queries involving large data comparisons.
- Enable **visualization** of tabular data (e.g., charts, graphs).
- Support **additional file types** (e.g., Word documents, Excel files).

```

