import os
import requests
from bs4 import BeautifulSoup
import uuid
import faiss
import numpy as np
import openai
from sentence_transformers import SentenceTransformer
from flask import Flask, request, jsonify

# Set OpenAI API Key
openai.api_key = "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"  # You can set it directly here or use an environment variable

# Initialize the Sentence Transformer model
embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

# Initialize FAISS index
dimension = 384  # Embedding size of MiniLM
index = faiss.IndexFlatL2(dimension)

# Metadata store
meta_store = []

# Function to scrape and chunk content from a website
def scrape_and_chunk(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    # Extract textual content
    paragraphs = [p.get_text() for p in soup.find_all('p')]
    content = " ".join(paragraphs)

    # Split content into chunks (e.g., 300 words per chunk)
    chunk_size = 300
    words = content.split()
    chunks = [" ".join(words[i:i + chunk_size]) for i in range(0, len(words), chunk_size)]

    # Generate embeddings for each chunk
    embeddings = [embedding_model.encode(chunk) for chunk in chunks]

    # Create metadata for each chunk
    metadata = [{"id": str(uuid.uuid4()), "url": url, "chunk": chunk} for chunk in chunks]

    return embeddings, metadata

# Function to add data to the FAISS index
def add_to_index(embeddings, metadata, index, meta_store):
    if embeddings:
        vectors = np.array(embeddings).astype('float32')
        index.add(vectors)

        # Store metadata separately
        meta_store.extend(metadata)

# Function to perform similarity search
def search(query, index, meta_store, top_k=5):
    query_embedding = embedding_model.encode([query]).astype('float32')
    distances, indices = index.search(query_embedding, top_k)

    # Retrieve metadata for the top results
    results = [meta_store[i] for i in indices[0]]
    return results

# Function to generate a response using OpenAI GPT (new API)
def generate_response(query, retrieved_chunks):
    context = "\n".join([f"- {chunk['chunk']}" for chunk in retrieved_chunks])
    prompt = f"""
    You are an intelligent assistant. Answer the following question based on the provided context:

    Context:
    {context}

    Question:
    {query}

    Answer:
    """
    
    # Using the new API for chat-based completions
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # You can use "gpt-3.5-turbo" or "gpt-4" if available
        messages=[
            {"role": "system", "content": "You are an intelligent assistant."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=200,
        temperature=0.7
    )
    
    return response['choices'][0]['message']['content'].strip()


# Flask app setup
app = Flask(__name__)

@app.route('/query', methods=['POST'])
def query():
    data = request.json
    query = data['query']

    # Perform search and generate response
    results = search(query, index, meta_store)
    response = generate_response(query, results)

    return jsonify({"response": response})

if __name__ == '__main__':
    # Start Flask app in the background
    from threading import Thread
    def run_flask():
        app.run(debug=True, use_reloader=False)  # Set use_reloader=False to avoid double startup
    thread = Thread(target=run_flask)
    thread.start()

    # Prompt for user input dynamically
    while True:
        url = input("Enter the website URL to scrape: ")
        query = input("Enter your query: ")

        # Scrape and index the website
        embeddings, metadata = scrape_and_chunk(url)
        add_to_index(embeddings, metadata, index, meta_store)

        # Send the query to the Flask server
        response = requests.post("http://127.0.0.1:5000/query", json={"query": query})
        if response.status_code == 200:
            print("Response:", response.json()["response"])
        else:
            print("Error:", response.status_code)

        # Optionally, you can break the loop by typing 'exit'
        if query.lower() == 'exit':
            print("Exiting...")
            break
