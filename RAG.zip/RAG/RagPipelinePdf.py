import os
import PyPDF2
from sentence_transformers import SentenceTransformer
from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.chains import RetrievalQA
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate

# Step 1: PDF Data Extraction
def extract_text_from_pdf(pdf_path):
    """Extract text from a PDF file."""
    with open(pdf_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        text = ""
        for page in reader.pages:
            text += page.extract_text() + "\n"
    return text

# Step 2: Chunking the Text
def chunk_text(text, chunk_size=500):
    """Split text into smaller chunks."""
    words = text.split()
    chunks = [" ".join(words[i:i + chunk_size]) for i in range(0, len(words), chunk_size)]
    return chunks

# Step 3: Embedding and Vector Database Setup
def create_vector_database(chunks, embedding_model_name="all-MiniLM-L6-v2"):
    """Create a FAISS vector database from text chunks."""
    embeddings = HuggingFaceEmbeddings(model_name=embedding_model_name)
    vector_db = FAISS.from_texts(chunks, embedding=embeddings)
    return vector_db

# Step 4: Query Handling with Custom Prompt
def query_vector_database(query, vector_db, llm_model="gpt-4"):
    """Handle a user query using the vector database and LLM with a custom prompt."""
    retriever = vector_db.as_retriever()
    llm = OpenAI(model=llm_model, temperature=0)

    # Custom prompt template
    custom_prompt = PromptTemplate(
        input_variables=["context", "question"],
        template="""
        You are an expert assistant. Use the following context to answer the question accurately.
        If the answer is not in the context, say you don't know.

        Context: {context}
        Question: {question}

        Answer:
        """
    )

    qa_chain = RetrievalQA(llm=llm, retriever=retriever, return_source_documents=True, chain_type_kwargs={"prompt": custom_prompt})
    response = qa_chain.run(query)
    return response

# Main Execution
if __name__ == "__main__":
    # Input PDF File
    pdf_path = "path_to_your_pdf.pdf"  # Replace with your PDF file path

    # Extract and Process Text
    extracted_text = extract_text_from_pdf(pdf_path)
    chunks = chunk_text(extracted_text)

    # Create Vector Database
    print("Creating vector database...")
    vector_db = create_vector_database(chunks)

    # User Query
    user_query = "What is the unemployment rate for individuals with a bachelor's degree?"
    print("Processing query...")

    # Query the Database
    response = query_vector_database(user_query, vector_db)
    print("Response:", response)
